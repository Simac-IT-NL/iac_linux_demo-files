In deze directory staan demo files die nodig zijn voor de workshop. Als het niet lukt met de mount opdracht in de workshop dan kun je ze hier downloaden. Zet ze dan in de directory ~/demo

